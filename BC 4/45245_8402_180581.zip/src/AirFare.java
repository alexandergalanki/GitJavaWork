interface AirFare {          //Interface airFare
    public Double showFare(String sourceCity, String destinationCity);
}
