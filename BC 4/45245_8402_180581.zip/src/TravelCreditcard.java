public class TravelCreditcard extends CreditCard{
 Double exchangePercentage;
 public Double getExchangePercentage() {
  return exchangePercentage;
 }
 public void setExchangePercentage(Double exchangePercentage) {
  this.exchangePercentage = exchangePercentage;
 }
 
}