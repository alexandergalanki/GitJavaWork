class CreditCard {
 String number,holderName;
 Double amount;
 public String getNumber() {
  return number;
 }
 public void setNumber(String number) {
  this.number = number;
 }
 public String getHolderName() {
  return holderName;
 }
 public void setHolderName(String holderName) {
  this.holderName = holderName;
 }
 public Double getAmount() {
  return amount;
 }
 public void setAmount(Double amount) {
  this.amount = amount;
 }
 
}