import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class Main
{
 public static void main(String[] args) throws IOException
 {
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  int no = 0;
  double cost = 0.0;
  System.out.println("Enter the number of stalls:");
  no = Integer.parseInt(br.readLine());
 
  List<Stall> list = new ArrayList<Stall>();
 
   while(no>0)
   {
       Stall stall=new Stall();
  String string = br.readLine();
  String st[]=string.split(",");
  stall.setStallName(st[0]);
  stall.setDetails(st[1]);
  stall.setStallArea(Double.parseDouble(st[2]));
  stall.setOwner(st[3]);
  list.add(stall);
  no--;
   }

    for (Stall st : list)
    {
    cost += st.getStallArea() * 150.0;
    }

    System.out.println("The total revenue is " + cost);
 }
}