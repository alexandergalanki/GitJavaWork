import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
		
		Scanner sc= new Scanner(System.in);          
		
		try                                           
		{
			System.out.println("Enter the user details");         
			String details= sc.nextLine();
			
			String a[]= details.split(",");                     
			
			User ob= new User(a[0],a[1],a[2],a[3]);           
			 
			UserBo ob2= new UserBo();                          
			ob2.validate(ob);                              
			System.out.println(ob);                         
		}
		
		catch(WeakPassword e)                 
		{ 
			System.out.println("WeakPasswordException: "+e.message);        
		}

	}

}