import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

public class Main{
    public static void main(String args[]) throws IOException{
       
         HashSet<String> h = new HashSet<String>();
     
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter number of words:");
      int n=sc.nextInt();
     
      for(int i=0;i<n;i++)
      {
          h.add(sc.next());
      }
     
       System.out.println("Unique set of words:");
      List<String> list = new ArrayList<String>(h);
        Collections.sort(list);
       
       for(String s:list)
       {
          System.out.println(s);
       }
     
       
       
    }
}