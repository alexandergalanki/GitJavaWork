import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;



public class Main{    
    public static void main(String[] args) throws NumberFormatException, IOException { 
		
		ArrayList<Employee> li= new ArrayList<>();  
		BufferedReader bff=new BufferedReader(new InputStreamReader(System.in));    
		
		System.out.println("Enter The Number of Employees");  
		int n= Integer.parseInt(bff.readLine());
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Employee "+(i+1)+" Details:");    
			System.out.println("Enter the Firstname");
			String first_name= bff.readLine();
			System.out.println("Enter the Lastname");
			String last_name= bff.readLine();
			System.out.println("Enter the Mobile");
			long mobile_number= Long.parseLong(bff.readLine());
			System.out.println("Enter the Email");
			String email_id= bff.readLine();
			System.out.println("Enter the Address");
			String address= bff.readLine();
			
			Employee ep= new Employee(first_name, last_name, mobile_number, email_id, address);  //Loading into constructor
			li.add(ep);       
		}
		Collections.sort(li,new Employee());                      
		Employee ep= new Employee();  
		System.out.println("Employee List:");
		System.out.format("%-15s %-15s %-15s %-30s %-15s\n","Firstname","Lastname","Mobile","Email","Address");
		for (Employee employee : li) {//Printing data
			System.out.format("%-15s %-15s %-15s %-30s %-15s\n",employee.getFirst_name(),employee.getLast_name(),employee.getMobile_number(),employee.getEmail_id(),employee.getAddress());
		}
	}

}


