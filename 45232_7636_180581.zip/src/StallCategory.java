import java.util.Scanner;
import static java.lang.System.out;

public class StallCategory
{
	private String detail;
	private String Name;
	
	{
	}
}




