import java.util.Scanner;
import static java.lang.System.out;

public class StallCategory
{
	private String getdetail;
	private String getName;
	
	{
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getDetail() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setName(String nextLine) {
		// TODO Auto-generated method stub
		
	}

	public void setDetail(String nextLine) {
		// TODO Auto-generated method stub
		
	}
}




